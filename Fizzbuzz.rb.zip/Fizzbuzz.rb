
# for fizzbuzz in 1..100
# 	puts "#{fizzbuzz}"
# end

# 3.times do	
# 	puts "Fizz"
# end

for n in 1..100
	if n % 5 == 0 && n % 3 ==0
		puts "Fizzbuzz"
	elsif n % 3 == 0
		puts "Fizz"
	elsif n % 5 == 0
		puts "Buzz"
	else
		puts "#{n}"

	end
end


 
			